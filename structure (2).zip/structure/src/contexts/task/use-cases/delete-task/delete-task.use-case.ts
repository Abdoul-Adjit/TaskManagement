import { Task, TaskCreate } from '../../domains/types'
import { ITaskRepository } from '../../infrastructure'

export class DeleteTaskUseCase {
  constructor(private taskRepository: ITaskRepository) {}

  async execute(id: string): Promise<void> {
    this.taskRepository.deleteTask(id)
  }
}
