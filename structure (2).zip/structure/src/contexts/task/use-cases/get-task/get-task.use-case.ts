import { Task } from '../../domains/types'
import { ITaskRepository } from '../../infrastructure'

export class GetTaskUseCase {
  constructor(private TaskRepository: ITaskRepository) {}

  async execute(id: string): Promise<Task | null> {
    const book = await this.TaskRepository.getTask(id)
    return book
  }
}
