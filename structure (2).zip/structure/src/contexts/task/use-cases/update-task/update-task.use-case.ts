import { Task, TaskCreate } from '../../domains/types'
import { ITaskRepository } from '../../infrastructure'

export class UpdateTaskUseCase {
  constructor(private TaskRepository: ITaskRepository) {}

  async execute(id: string, task: Task): Promise<Task> {
    return await this.TaskRepository.updateTask(id, task)
  }
}
