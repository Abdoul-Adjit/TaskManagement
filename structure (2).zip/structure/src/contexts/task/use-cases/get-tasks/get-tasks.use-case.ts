import { Task } from '../../domains/types'
import { ITaskRepository } from '../../infrastructure'

export class GetTasksUseCase {
  constructor(private TaskRepository: ITaskRepository) {}

  async execute(): Promise<Task[]> {
    return await this.TaskRepository.getAllTasks()
  }
}
