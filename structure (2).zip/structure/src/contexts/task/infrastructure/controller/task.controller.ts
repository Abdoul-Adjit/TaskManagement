import { Request, Response } from 'express'
import { GetTasksUseCase } from '../../use-cases/get-tasks'
import { AddTaskUseCase } from '../../use-cases/add-task'
import { GetTaskUseCase } from '../../use-cases/get-task'
import { UpdateTaskUseCase } from '../../use-cases/update-task'
import { DeleteTaskUseCase } from '../../use-cases/delete-task'
import { ValidationError, validate } from 'jsonschema'
import { ValidatorResult } from 'jsonschema'

const TaskCreateSchema = {
  id: '/Task',
  type: 'object',
  properties: {
    title: {
      type: 'string'
    },
    description: {
      type: 'string'
    },
    priorite: {
      type: 'int'
    }
  },
  required: ['title']
}

export class TaskController {
  constructor(
    private readonly getTasksUseCase: GetTasksUseCase,
    private readonly addTaskUseCase: AddTaskUseCase,
    private readonly getTaskUseCase: GetTaskUseCase,
    private readonly deleteTaskUseCase: DeleteTaskUseCase,
    private readonly updateTaskUseCase: UpdateTaskUseCase
  ) {}

  async getTasks(req: Request, res: Response) {
    var tasks = await this.getTasksUseCase.execute()
    if (req.query.sort === 'priorite') {
      tasks.sort(function (a, b) {
        return a.priorite - b.priorite
      })
    }
    res.status(200).json(tasks)
  }

  async updateTask(req: Request, res: Response) {
    const validatorResult: ValidatorResult = validate(req.body, TaskCreateSchema)
    if (validatorResult.valid) {
      // try {
      const task = await this.updateTaskUseCase.execute(req.params.id, req.body)
      res.status(201).json(task)
      //  } catch (error) {
      //   res.status(500).json(error)
      //  }
    } else {
      res.status(400).json(validatorResult.errors)
    }
  }

  /*async updateTask(req: Request, res: Response) {
    const result = validate(req.body, TaskCreateSchema)
    if (!result.valid) {
      const errors = result.errors.map((error: ValidationError) => {
        return {
          message: error.message
        }
      })
      return res.status(400).json(errors)
    }
    const task = await this.updateTaskUseCase.execute(req.params.id, req.body)
    return res.status(201).json(task)
  }
*/
  async addTask(req: Request, res: Response) {
    const result = validate(req.body, TaskCreateSchema)
    if (!result.valid) {
      const errors = result.errors.map((error: ValidationError) => {
        return {
          message: error.message
        }
      })
      return res.status(400).json(errors)
    }
    const task = await this.addTaskUseCase.execute(req.body)
    return res.status(201).json(task)
  }

  async getTask(req: Request, res: Response) {
    const task = await this.getTaskUseCase.execute(req.params.id)
    res.status(200).json(task)
  }

  async deleteTask(req: Request, res: Response) {
    console.log(req.params.id)
    await this.deleteTaskUseCase.execute(req.params.id)
    res.status(204).json({
      message: 'Task deleted successfully'
    })
  }
  /*
  async updateTask(req: Request, res: Response) {
    const { title, description,priorite, status } = req.body
    const task = await this.updateTaskUseCase.execute( title, description,priorite, status)
    res.status(200).json(task)
  }



  // Q5
  async getTask(req: Request, res: Response) {
    const { id } = req.params
    const task = await this.getTaskUseCase.execute({ id })
    res.status(200).json(task)
  }
  
  // Q6
  async getTaskByName(req: Request, res: Response) {

    const { name } = req.params
    const task = await this.getTaskByNameUseCase.execute({ name })
    res.status(200).json(task)
  }

  // Q7

  async getTaskByDescription(req: Request, res: Response) {

    const { description } = req.params
    const task = await this.getTaskByDescriptionUseCase.execute({ description })
    res.status(200).json(task)
  }

  // Q8

  async getTaskByStatus(req: Request, res: Response) {

    const { status } = req.params
    const task = await this.getTaskByStatusUseCase.execute({ status })
    res.status(200).json(task)
  }

  // Q9

  async getTaskByDate(req: Request, res: Response) {

    const { date } = req.params
    const task = await this.getTaskByDateUseCase.execute({ date })
    res.status(200).json(task)
  }

*/
}
