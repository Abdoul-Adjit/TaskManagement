import { Router } from 'express'
import { TaskController } from './controller'

export function taskRoutes(controller: TaskController): Router {
  const router = Router()

  router.get('/', controller.getTasks.bind(controller))
  router.post('/', controller.addTask.bind(controller))
  router.get('/:id', controller.getTask.bind(controller))
  router.delete('/:id', controller.deleteTask.bind(controller))
  router.get('/sort', controller.getTasks.bind(controller))
  router.patch('/:id', controller.updateTask.bind(controller))
  return router
}
