/*
  Warnings:

  - Made the column `description` on table `Tache` required. This step will fail if there are existing NULL values in that column.

*/
-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Tache" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "priorite" INTEGER NOT NULL
);
INSERT INTO "new_Tache" ("description", "id", "priorite", "title") SELECT "description", "id", "priorite", "title" FROM "Tache";
DROP TABLE "Tache";
ALTER TABLE "new_Tache" RENAME TO "Tache";
PRAGMA foreign_key_check;
PRAGMA foreign_keys=ON;
