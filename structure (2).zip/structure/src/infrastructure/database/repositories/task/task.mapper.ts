import { Tache } from '@prisma/client'
import { TaskRaw } from '../../../../contexts/task'

// export function toBookRaw(book: Task): TaskRaw {
// TODO: use real types
export function toTaskRaw(task: Tache): Tache {
  return {
    id: task.id,
    title: task.title,
    description: task.description,
    priorite: task.priorite
  }
}
