import { Tache } from '@prisma/client'
import { TaskCreateRaw, TaskRaw, ITaskRepository } from '../../../../contexts/task'
import { RelationalDatabase } from '../../database'
import { toTaskRaw } from './task.mapper'

export class TaskRepository implements ITaskRepository {
  constructor(private readonly database: RelationalDatabase) {}

  //TODO: to complete
  async addTask(task: TaskCreateRaw): Promise<TaskRaw> {
    const newTask = await this.database.client.tache.create({ data: task })
    return toTaskRaw(newTask)
  }

  async getAllTasks(): Promise<TaskRaw[]> {
    const Tasks = await this.database.client.tache.findMany()
    return Tasks.map(toTaskRaw)
  }

  async getTask(id: string): Promise<TaskRaw | null> {
    const Task = await this.database.client.tache.findUnique({ where: { id } })
    return Task ? toTaskRaw(Task) : null
  }
  async deleteTask(id: string): Promise<void> {
    await this.database.client.tache.delete({ where: { id: id } })
  }
  /*async updateTask(task: Tache): Promise<Tache> {
    const updatedTask = await this.database.client.tache.update({
      where: { id: task.id },
      data: task
    })
    return toTaskRaw(updatedTask)
  }
  */
  async updateTask(id: string, task: TaskRaw): Promise<TaskRaw> {
    const updatedTask = await this.database.client.task.update({ where: { id }, data: task })

    if (!updatedTask) {
      throw new Error('Task not found')
    }

    return toTaskRaw(updatedTask)
  }
}
